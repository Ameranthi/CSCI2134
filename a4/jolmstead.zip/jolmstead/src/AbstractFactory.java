 public interface AbstractFactory<T> {
        T create(TimBot botType);
    }