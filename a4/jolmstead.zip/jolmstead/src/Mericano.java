public class Mericano extends Plant {


    public Mericano(int energy, int  growth, String name, boolean harvestable , boolean ripe){
        super(energy, growth, name, true , false);
    }
}
